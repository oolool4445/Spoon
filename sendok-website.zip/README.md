# 🥄 Dunia Sendok

Project website sederhana bertema sendok.

## Fitur
- HTML, CSS, JavaScript sederhana
- Desain minimalis
- Interaksi tombol

## Cara menjalankan
Buka file `index.html` di browser.
