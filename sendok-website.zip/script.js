function showMessage() {
  alert("Sendok itu keren! 🥄");
}
